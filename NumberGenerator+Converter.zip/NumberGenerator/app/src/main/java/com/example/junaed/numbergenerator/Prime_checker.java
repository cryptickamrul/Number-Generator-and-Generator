package com.example.junaed.numbergenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Prime_checker extends AppCompatActivity {

    EditText editText;
    Button button;
    TextView textView;


    StringBuilder stringBuilder = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prime_checker);

        setTitle("Prime Number Check");

        editText = findViewById(R.id.primeChckerEditTextId);
        button = findViewById(R.id.primeChckerButtonId);
        textView = findViewById(R.id.primeCheckerTextViewId);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stringBuilder.setLength(0);
                String string = editText.getText().toString();
                int n = Integer.parseInt(string);
                textView.setText(check_prime(n));
            }
        });
    }

    public String check_prime(int n){
        int check = 0;
        for(int i = 2; i < n; i++){
            int k = n / i;
            if(n % i == 0){
                check = 1;
                stringBuilder.append(n+" is not a prime number\n");
                stringBuilder.append("Because "+n+" is divided by "+i+".");
                break;
            }
        }

        if(check==0){
            stringBuilder.append(n+" is a prime number");
        }
        return stringBuilder.toString();
    }
}
