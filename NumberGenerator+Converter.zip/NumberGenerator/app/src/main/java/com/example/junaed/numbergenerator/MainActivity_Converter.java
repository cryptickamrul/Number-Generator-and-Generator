package com.example.junaed.numbergenerator;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity_Converter extends AppCompatActivity implements View.OnClickListener{

    public Button decimal, binary, octal, hexadecimal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setTitle("Number Conversation");

        setContentView(R.layout.activity_main_converter);
        decimal = findViewById(R.id.decimalId);
        binary = findViewById(R.id.binaryId);
        octal = findViewById(R.id.octalId);
        hexadecimal = findViewById(R.id.hexaId);

        decimal.setOnClickListener(this);
        binary.setOnClickListener(this);
        octal.setOnClickListener(this);
        hexadecimal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.decimalId){
            Intent intent = new Intent(MainActivity_Converter.this, DecimalActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.binaryId){
            Intent intent = new Intent(MainActivity_Converter.this, BinaryActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.octalId){
            Intent intent = new Intent(MainActivity_Converter.this, OctalActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.hexaId){
            Intent intent = new Intent(MainActivity_Converter.this, HexaDecimalActivity.class);
            startActivity(intent);
        }
    }

}
