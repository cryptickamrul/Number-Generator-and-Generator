package com.example.junaed.numbergenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Math.pow;

public class AemstrongActivity extends AppCompatActivity {
    EditText editText;
    Button button;
    TextView textView;

    StringBuilder stringBuilder = new StringBuilder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aemstrong);

        setTitle("Armstrong  Number Generator");

        editText = findViewById(R.id.armsronEditTextId);
        button = findViewById(R.id.armsronButtonId);
        textView = findViewById(R.id.armsronTextViewId);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    stringBuilder.setLength(0);
                    int n = Integer.parseInt(editText.getText().toString());
                    if(n>100000)
                        textView.setText("Out of Range");
                    else
                        textView.setText(armstrongNumbers(n));
                }catch (Exception e){
                    Toast.makeText(AemstrongActivity.this,"Something Wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    String armstrongNumbers(int n){
        for(int i = 1; i <= n; i++){
            int digit = getDegit(i);
            int sum = 0;
            int number = i;
            while (number!=0){
                sum= (int) (sum+pow((number%10),digit));
                number = number / 10;
            }
            if(sum==i){
                stringBuilder.append(i+"  ");
            }
        }
        return stringBuilder.toString();
    }

    int getDegit(int i){
        int count = 0;
        while(i!=0){
            i = i/10;
            count++;
        }
        return count;
    }
}
