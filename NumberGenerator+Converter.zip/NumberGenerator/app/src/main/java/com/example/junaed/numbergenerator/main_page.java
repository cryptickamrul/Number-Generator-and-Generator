package com.example.junaed.numbergenerator;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class main_page extends AppCompatActivity implements View.OnClickListener {

    Button generateBtn, convertBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        generateBtn = findViewById(R.id.generateId);
        convertBtn = findViewById(R.id.convertId);

        generateBtn.setOnClickListener(this);
        convertBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.convertId){
            Intent intent = new Intent(main_page.this, MainActivity_Converter.class);
            startActivity(intent);
        }else{
            Intent intent = new Intent(main_page.this, MainActivity_Generator.class);
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_announcement_black_24dp);
        builder.setTitle("Where ???");
        builder.setMessage("Wanted to exit ??");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.shareId){
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");

            String subject = "Number Generator App";
            String body = "This will help you to generate prime,fibonacci and armstrong numbers.\ncom.example.junaed.numbergenerator";

            intent.putExtra(Intent.EXTRA_SUBJECT,subject);
            intent.putExtra(Intent.EXTRA_TEXT,body);

            startActivity(Intent.createChooser(intent,"Share with : "));
        }else if(item.getItemId()==R.id.feedbackId){
            Intent intent = new Intent(main_page.this,FeedbackActivity.class);
            startActivity(intent);

        }else if(item.getItemId()==R.id.aboutId){
            Intent intent = new Intent(main_page.this,AboutActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
