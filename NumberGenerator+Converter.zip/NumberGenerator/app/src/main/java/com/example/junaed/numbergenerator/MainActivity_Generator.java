package com.example.junaed.numbergenerator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_Generator extends AppCompatActivity implements View.OnClickListener{
    Button prime,armstrong,fibonacci,primeChecher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prime = findViewById(R.id.primeId);
        armstrong = findViewById(R.id.armstrongId);
        fibonacci = findViewById(R.id.fibonacciId);
        primeChecher = findViewById(R.id.primeCheckerId);

        prime.setOnClickListener(this);
        armstrong.setOnClickListener(this);
        fibonacci.setOnClickListener(this);
        primeChecher.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.primeId){
            Intent intent = new Intent(MainActivity_Generator.this,PrimeActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.armstrongId){
            Intent intent = new Intent(MainActivity_Generator.this,AemstrongActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.fibonacciId){
            Intent intent = new Intent(MainActivity_Generator.this,FibonacciActivity.class);
            startActivity(intent);
        }else if(v.getId()==R.id.primeCheckerId){
            Intent intent = new Intent(MainActivity_Generator.this,Prime_checker.class);
            startActivity(intent);
        }
    }



}
