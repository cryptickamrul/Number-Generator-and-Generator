package com.example.junaed.numbergenerator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class OctalActivity extends AppCompatActivity {

    private EditText editText;
    private TextView textView,deatailsTextView;
    private Spinner spinner;
    private Button button;
    private long number,n;
    NumberConverter numberConverter;

    String[] strings ;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_octal);

        setTitle("Octal to All Conversation");

        editText = findViewById(R.id.octalEditTextId);
        textView = findViewById(R.id.octalTextviewId);
        spinner = findViewById(R.id.octalSpinnerId);
        button = findViewById(R.id.octalButtonId);
        spinner = findViewById(R.id.octalSpinnerId);
        deatailsTextView = findViewById(R.id.detailsTextviewId);

        strings = getResources().getStringArray(R.array.base_numbers);

        adapter = new ArrayAdapter<String>(OctalActivity.this,R.layout.sample,R.id.customTextviewId,strings );

        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                n = position + 2;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String string = editText.getText().toString();
                    number = Long.parseLong(string);

                    numberConverter = new NumberConverter((long) number,(long) n);
                    deatailsTextView.setText(numberConverter.octaltoAllDetails());
                    textView.setText(numberConverter.octaltoAll());
                }catch (Exception e){
                    Toast.makeText(OctalActivity.this,"Something Wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
