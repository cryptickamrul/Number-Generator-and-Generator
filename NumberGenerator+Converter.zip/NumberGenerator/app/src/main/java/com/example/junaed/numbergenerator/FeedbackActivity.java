package com.example.junaed.numbergenerator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FeedbackActivity extends AppCompatActivity implements View.OnClickListener{

    Button sendButton, clearButton;
    EditText nameEditText, massageEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        setTitle("Feedback");

        sendButton = findViewById(R.id.sendButtonId);
        clearButton = findViewById(R.id.clearButtonId);

        nameEditText = findViewById(R.id.feedbackEditTextNameId);
        massageEditText = findViewById(R.id.feedbackEditTextDetailsId);

        sendButton.setOnClickListener(this);
        massageEditText.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        try {
            String name = nameEditText.getText().toString();
            String massage = massageEditText.getText().toString();

            if(v.getId()==R.id.sendButtonId){
                Intent intent = new Intent(Intent.ACTION_SEND);

                intent.setType("text/email");

                intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"kamrul13515@gmail.com"});

                intent.putExtra(Intent.EXTRA_SUBJECT,"Feed Back From App");

                intent.putExtra(Intent.EXTRA_TEXT,"Name : "+name+"\nMassage : "+massage);

                startActivity( Intent.createChooser(intent,"Feedback with : "));


            }else if(v.getId()==R.id.clearButtonId){
                nameEditText.setText("");
                massageEditText.setText("");
            }
        }catch (Exception e){
            Toast.makeText(FeedbackActivity.this,"Wrong Input",Toast.LENGTH_SHORT).show();
        }
    }
}
