package com.example.junaed.numbergenerator;

import static java.lang.Math.pow;

public class NumberConverter {
    long number;
    long n;
    public NumberConverter(long number, long n) {
        this.number = number;
        this.n = n;
    }

    String decimaltoAll(long decimal){
        if (decimal==-999){
            return "Your input is not correct to convert. Check your input formet";
        }
        StringBuilder stringBuilder = new StringBuilder();
        long reminder = decimal;
        while (reminder!=0){
            if((reminder % n)==10)
                stringBuilder.append('A');
            else  if((reminder % n)==11)
                stringBuilder.append('B');
            else  if((reminder % n)==12)
                stringBuilder.append('C');
            else  if((reminder % n)==13)
                stringBuilder.append('D');
            else  if((reminder % n)==14)
                stringBuilder.append('E');
            else  if((reminder % n)==15)
                stringBuilder.append('F');
            else
                stringBuilder.append(reminder % n);
            reminder = reminder / n;
        }
        stringBuilder.reverse();
        String string = stringBuilder.toString();
        return "Number with base  ' "+n+" '  :  "+string;
    }


    String decimaltoAllDetails(long decimal){
        if (decimal==-999){
            return "Your input is not correct to convert. Check your input formet";
        }
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilderDetails = new StringBuilder();
        long reminder = decimal;
        while (reminder!=0){
            if((reminder % n)==10) {
                stringBuilder.append('A');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(A)\n");
            }
            else  if((reminder % n)==11) {
                stringBuilder.append('B');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(B)\n");
            }
            else  if((reminder % n)==12) {
                stringBuilder.append('C');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(C)\n");
            }
            else  if((reminder % n)==13) {
                stringBuilder.append('D');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(D)\n");
            }
            else  if((reminder % n)==14) {
                stringBuilder.append('E');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(E)\n");
            }
            else  if((reminder % n)==15) {
                stringBuilder.append('F');
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"(F)\n");
            }
            else {
                stringBuilderDetails.append(reminder+"/"+n+"="+reminder / n+"    Remainder : "+reminder % n+"\n");
                stringBuilder.append(reminder % n);
            }
            reminder = reminder / n;
        }
        stringBuilder.reverse();
        String string = stringBuilder.toString();
        return stringBuilderDetails+"Number with base  ' "+n+" '  :  "+string;
    }


    String binarytoAll(){
        long remainder = number;
        long decimal = 0;
        long i = 0;
        while (remainder != 0){
            if((remainder % 10)>=2)
            {
                decimal = -999;
                break;
            }
            decimal = (remainder % 10)*(long)pow(2,i)+decimal;
            remainder = remainder / 10;
            i=i+1;
        }
        return decimaltoAll(decimal);
        //String stringBuilder= new StringBuffer().append(decimal).toString();
        //return stringBuilder;
    }


    String binarytoAllDetails(){
        StringBuilder stringBuilder = new StringBuilder();
        long remainder = number;
        long decimal = 0;
        long i = 0;
        while (remainder != 0){
            if((remainder % 10)>=2)
            {
                decimal = -999;
                break;
            }

            stringBuilder.append((remainder % 10)+"*2^"+i+"="+(remainder % 10)*(long)pow(2,i)+"\n");
            decimal = (remainder % 10)*(long)pow(2,i)+decimal;
            remainder = remainder / 10;
            i=i+1;

        }
        stringBuilder.append("Number with base  ' 10 '  : "+ decimal);
        return stringBuilder.toString()+"\n"+decimaltoAllDetails(decimal);
        //String stringBuilder= new StringBuffer().append(decimal).toString();
        //return stringBuilder;
    }

    String octaltoAllDetails(){
        StringBuilder stringBuilder = new StringBuilder();
        long remainder = number;
        long decimal = 0;
        long i = 0;
        while (remainder != 0){
            if((remainder % 10)>=8)
            {
                decimal = -999;
                break;
            }
            stringBuilder.append((remainder % 10)+"*8^"+i+"="+(remainder % 10)*(long)pow(8,i)+"\n");
            decimal = (remainder % 10)*(long)pow(8,i)+decimal;
            remainder = remainder / 10;
            i=i+1;
        }
        stringBuilder.append("Number with base  ' 10 '  : "+ decimal);
        return stringBuilder.toString()+"\n"+decimaltoAllDetails(decimal);
    }

    String hexatoAllDetails(String string){
        StringBuilder stringBuilder = new StringBuilder();
        int j = 0;
        long decimal = 0;
        int i = (string.length()-1);
        for (; i>=0;i--){
            if(string.charAt(i)=='A') {
                decimal = 10 * (long) pow(16, j) + decimal;
                stringBuilder.append("(A)"+10+"*16^"+j+"="+(10 * (long) pow(16, j))+"\n");
            }
            else if(string.charAt(i)=='B') {
                decimal = 11 * (long) pow(16, j) + decimal;
                stringBuilder.append("(B)"+11+"*16^"+j+"="+(11 * (long) pow(16, j))+"\n");
            }
            else if(string.charAt(i)=='C') {
                decimal = 12 * (long) pow(16, j) + decimal;
                stringBuilder.append("(C)"+12+"*16^"+j+"="+(12 * (long) pow(16, j))+"\n");
            }
            else if(string.charAt(i)=='D') {
                decimal = 13 * (long) pow(16, j) + decimal;
                stringBuilder.append("(D)"+13+"*16^"+j+"="+(13 * (long) pow(16, j))+"\n");
            }
            else if(string.charAt(i)=='E') {
                decimal = 14 * (long) pow(16, j) + decimal;
                stringBuilder.append("(E)"+14+"*16^"+j+"="+(14* (long) pow(16, j))+"\n");
            }
            else if(string.charAt(i)=='F') {
                decimal = 15 * (long) pow(16, j) + decimal;
                stringBuilder.append("(F)"+15+"*16^"+j+"="+(15 * (long) pow(16, j))+"\n");
            }
            else {
                char ch = string.charAt(i);
                stringBuilder.append(ch+"*16^"+j+"="+(Character.getNumericValue(ch) * (long) pow(16, j))+"\n");
                decimal = (Character.getNumericValue(ch) * (long) pow(16, j)) + decimal;
                //decimal = 1 * (long)pow(16,2)+decimal;
            }
            j++;
        }
        //String stringBuilder= new StringBuffer().append(decimal).toString();
        stringBuilder.append("Number with base  ' 10 '  : "+ decimal);
        return stringBuilder.toString()+"\n"+decimaltoAllDetails(decimal);
    }

    String octaltoAll(){
        long remainder = number;
        long decimal = 0;
        long i = 0;
        while (remainder != 0){
            if((remainder % 10)>=8)
            {
                decimal = -999;
                break;
            }
            decimal = (remainder % 10)*(long)pow(8,i)+decimal;
            remainder = remainder / 10;
            i=i+1;
        }
        return decimaltoAll(decimal);
    }

    String hexatoAll(String string){
        long decimal = 0;
        int j = 0;
        int i = (string.length()-1);
        for (; i>=0;i--){
            if(string.charAt(i)=='A')
                decimal = 10 * (long)pow(16,j)+decimal;
            else if(string.charAt(i)=='B')
                decimal = 11 * (long)pow(16,j)+decimal;
            else if(string.charAt(i)=='C')
                decimal = 12 * (long)pow(16,j)+decimal;
            else if(string.charAt(i)=='D')
                decimal = 13 * (long)pow(16,j)+decimal;
            else if(string.charAt(i)=='E')
                decimal = 14 * (long)pow(16,j)+decimal;
            else if(string.charAt(i)=='F')
                decimal = 15 * (long)pow(16,j)+decimal;
            else {
                char ch = string.charAt(i);
                decimal = (Character.getNumericValue(ch) * (long) pow(16, j)) + decimal;
                //decimal = 1 * (long)pow(16,2)+decimal;
            }
            j++;
        }
        //String stringBuilder= new StringBuffer().append(decimal).toString();
        return decimaltoAll(decimal);
    }
}
