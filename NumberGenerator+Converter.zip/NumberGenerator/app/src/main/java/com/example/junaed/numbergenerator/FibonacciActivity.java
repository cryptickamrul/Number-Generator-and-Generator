package com.example.junaed.numbergenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class FibonacciActivity extends AppCompatActivity {
    EditText editText;
    Button button;
    TextView textView;

    StringBuilder stringBuilder;

    long a , b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fibonacci);

        setTitle("Fibonacci Sequence Generator");

        editText = findViewById(R.id.fibonacciEditTextId);
        button = findViewById(R.id.fibonacciButtonId);
        textView = findViewById(R.id.fibonacciTextViewId);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stringBuilder = new StringBuilder();
                a = 1;
                b = 1;
                try {
                    stringBuilder.setLength(0);
                    int n = 0;
                    n = Integer.parseInt(editText.getText().toString());
                    if(n>50)
                        textView.setText("Out of Range");
                    else {
                        String value = fibonacciNumbers(n);
                        textView.setText(value);
                    }
                }catch (Exception e){
                    Toast.makeText(FibonacciActivity.this,"Something Wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    String fibonacciNumbers(int n){
        int count = 2;
        stringBuilder.append(a+"  ");
        stringBuilder.append(b+"  ");
        while (count!=n){
            long sum = a + b;
            stringBuilder.append(sum+"  ");
            a = b;
            b = sum;
            count++;
        }
        return stringBuilder.toString();
    }
}
