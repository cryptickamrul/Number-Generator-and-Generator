package com.example.junaed.numbergenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Math.sqrt;

public class PrimeActivity extends AppCompatActivity {
    EditText editText;
    Button button;
    TextView textView;


    StringBuilder stringBuilder = new StringBuilder();

    long arr[] = new long[1001000];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prime);

        setTitle("Prime Number Generator");

        editText = findViewById(R.id.primeEditTextId);
        button = findViewById(R.id.primeButtonId);
        textView = findViewById(R.id.primeTextViewId);



        sieve();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    stringBuilder.setLength(0);
                    String string = editText.getText().toString();
                    int n = Integer.parseInt(string);
                    if(n>10000)
                        textView.setText("Out of Range");
                    else
                        textView.setText(getPrime(n));
                }catch (Exception e){
                    Toast.makeText(PrimeActivity.this,"Something Wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void sieve()
    {
        int i,j,root;
        for (i = 2; i < arr.length;i++){
            arr[i] = 1;
        }
        root = (int) (sqrt(1001000)+2);

        for(i = 2; i <= root; i++){
            if(arr[i]==1){
                for(j = 2; j * i < 1001000; j++){
                    arr[i*j]=0;
                }
            }
        }
    }

    String getPrime(int n){
        int i = 0,count=2;
        while (i!=n){
            if(arr[count]==1){
                i++;
                stringBuilder.append(i+".     "+count+"\n");
            }
            count++;
        }
        return stringBuilder.toString();
    }
}
